# Gerador de Senhas Seguras

Projeto simples usando HTML, CSS e JavaScript puro.

## Funcionalidades

- Geração de senhas aleatórias
- Opções de caracteres (maiúsculas, minúsculas, números, símbolos)
- Botão de cópia para área de transferência

## Como usar

Abra o arquivo `index.html` em qualquer navegador.

## Autor

Projeto de portfólio para estágio em desenvolvimento web.
